"""
Advanced Admin Panel Routes
مسیرهای پنل مدیریت پیشرفته
"""

from flask import render_template, request, jsonify, redirect, url_for, flash
from app import app, db
from models import Signal, Analysis, TelegramMessage
from models_navasan import PriceRecord, BotStatistics, NavasanPriceAlert, SystemLog
from services.price_bot_service import price_bot_service
from services.navasan_service import navasan_service
from datetime import datetime, timedelta, date
from typing import Dict
import json
import asyncio


@app.route('/admin/advanced')
def admin_advanced_panel():
    """پنل مدیریت پیشرفته با قابلیت ویرایش سیگنال‌ها"""
    try:
        # Get recent signals with detailed info
        recent_signals = Signal.query.order_by(Signal.created_at.desc()).limit(15).all()
        
        # Separate pending signals for approval
        pending_signals = Signal.query.filter_by(status='PENDING_APPROVAL').order_by(Signal.created_at.desc()).limit(10).all()
        
        # Get bot statistics
        today = datetime.now().date()
        bot_stats = BotStatistics.query.filter_by(date=today).first()
        
        # Get recent price records
        recent_prices = PriceRecord.query.order_by(PriceRecord.timestamp.desc()).limit(5).all()
        
        # Get active alerts
        active_alerts = NavasanPriceAlert.query.filter_by(acknowledged=False).order_by(NavasanPriceAlert.timestamp.desc()).limit(10).all()
        
        # Get recent system logs (filtered for signal activity)
        recent_logs = SystemLog.query.filter(
            SystemLog.log_type.in_(['SIGNAL_GENERATED', 'SIGNAL_APPROVED', 'SIGNAL_REJECTED', 'PATTERN_DETECTED'])
        ).order_by(SystemLog.timestamp.desc()).limit(20).all()
        
        # Calculate enhanced summary stats
        total_signals = Signal.query.count()
        pending_count = Signal.query.filter_by(status='PENDING_APPROVAL').count()
        approved_signals = Signal.query.filter_by(admin_approved=True).count()
        rejected_signals = Signal.query.filter_by(status='REJECTED').count()
        
        # Signal performance stats
        successful_signals = Signal.query.filter_by(outcome='SUCCESSFUL').count()
        failed_signals = Signal.query.filter_by(outcome='FAILED').count()
        
        # Today's signal activity
        today_start = datetime.combine(today, datetime.min.time())
        today_signals = Signal.query.filter(Signal.created_at >= today_start).count()
        
        # Price action patterns detected today
        today_patterns = SystemLog.query.filter(
            SystemLog.timestamp >= today_start,
            SystemLog.log_type == 'PATTERN_DETECTED'
        ).count()
        
        summary_stats = {
            'total_signals': total_signals,
            'pending_signals': pending_count,
            'approved_signals': approved_signals,
            'rejected_signals': rejected_signals,
            'success_rate': round((successful_signals / (successful_signals + failed_signals) * 100) if (successful_signals + failed_signals) > 0 else 0, 2),
            'approval_rate': round((approved_signals / total_signals * 100) if total_signals > 0 else 0, 2),
            'today_signals': today_signals,
            'today_patterns': today_patterns,
            'active_alerts': len(active_alerts),
            'scheduler_running': getattr(price_bot_service.scheduler, 'running', False),
            'system_health': _calculate_system_health(today_signals, today_patterns, len(active_alerts))
        }
        
        return render_template('admin_advanced.html',
                             signals=recent_signals,
                             pending_signals=pending_signals,
                             bot_stats=bot_stats,
                             recent_prices=recent_prices,
                             active_alerts=active_alerts,
                             recent_logs=recent_logs,
                             summary_stats=summary_stats)
                             
    except Exception as e:
        app.logger.error(f"Error in advanced admin panel: {e}")
        flash(f'خطا در بارگذاری پنل مدیریت: {str(e)}', 'error')
        return redirect(url_for('admin'))


def _calculate_system_health(today_signals: int, today_patterns: int, active_alerts: int) -> Dict:
    """محاسبه وضعیت سلامت سیستم"""
    health_score = 100
    status = "عالی"
    issues = []
    
    # کاهش امتیاز برای هشدارهای فعال
    if active_alerts > 5:
        health_score -= 20
        issues.append(f"{active_alerts} هشدار فعال")
    elif active_alerts > 2:
        health_score -= 10
    
    # کاهش امتیاز برای عدم تولید سیگنال
    if today_signals == 0:
        health_score -= 30
        issues.append("هیچ سیگنالی امروز تولید نشده")
    elif today_signals < 2:
        health_score -= 15
        issues.append("سیگنال‌های کم")
    
    # کاهش امتیاز برای عدم تشخیص الگو
    if today_patterns == 0:
        health_score -= 25
        issues.append("هیچ الگویی تشخیص داده نشده")
    
    # تعیین وضعیت
    if health_score >= 80:
        status = "عالی"
        color = "success"
    elif health_score >= 60:
        status = "خوب"
        color = "info"
    elif health_score >= 40:
        status = "متوسط"
        color = "warning"
    else:
        status = "نیاز به توجه"
        color = "danger"
    
    return {
        'score': max(0, health_score),
        'status': status,
        'color': color,
        'issues': issues
    }


@app.route('/admin/signal/<int:signal_id>/edit', methods=['GET', 'POST'])
def edit_signal(signal_id):
    """ویرایش سیگنال توسط ادمین"""
    try:
        signal = Signal.query.get_or_404(signal_id)
        
        if request.method == 'POST':
            # دریافت داده‌های جدید از فرم
            new_entry_price = float(request.form.get('entry_price', signal.entry_price))
            new_stop_loss = float(request.form.get('stop_loss', signal.stop_loss))
            new_take_profit = float(request.form.get('take_profit', signal.take_profit))
            new_position_size = float(request.form.get('position_size', signal.position_size or 1.0))
            admin_notes = request.form.get('admin_notes', '')
            
            # اعتبارسنجی داده‌ها
            if new_entry_price <= 0 or new_stop_loss <= 0 or new_take_profit <= 0:
                flash('قیمت‌ها باید مثبت باشند', 'error')
                return render_template('edit_signal.html', signal=signal)
            
            # محاسبه Risk/Reward جدید
            if signal.signal_type == 'BUY':
                new_risk = abs(new_entry_price - new_stop_loss)
                new_reward = abs(new_take_profit - new_entry_price)
            else:  # SELL
                new_risk = abs(new_stop_loss - new_entry_price)
                new_reward = abs(new_entry_price - new_take_profit)
            
            new_rr_ratio = new_reward / new_risk if new_risk > 0 else 1.0
            
            # به‌روزرسانی سیگنال
            signal.entry_price = new_entry_price
            signal.stop_loss = new_stop_loss
            signal.take_profit = new_take_profit
            signal.position_size = new_position_size
            signal.risk_reward_ratio = new_rr_ratio
            signal.admin_notes = admin_notes
            signal.last_modified = datetime.utcnow()
            signal.modified_by_admin = True
            
            db.session.commit()
            
            # ثبت لاگ
            _log_admin_action('SIGNAL_MODIFIED', f'سیگنال {signal_id} ویرایش شد')
            
            flash('سیگنال با موفقیت به‌روزرسانی شد', 'success')
            return redirect(url_for('admin_advanced_panel'))
        
        # GET request - نمایش فرم ویرایش
        return render_template('edit_signal.html', signal=signal)
        
    except Exception as e:
        app.logger.error(f"خطا در ویرایش سیگنال {signal_id}: {e}")
        flash(f'خطا در ویرایش سیگنال: {str(e)}', 'error')
        return redirect(url_for('admin_advanced_panel'))


@app.route('/admin/signal/<int:signal_id>/approve', methods=['POST'])
def approve_signal(signal_id):
    """تایید سیگنال توسط ادمین"""
    try:
        signal = Signal.query.get_or_404(signal_id)
        
        # بررسی وضعیت فعلی
        if signal.status != 'PENDING_APPROVAL':
            flash('این سیگنال قبلاً پردازش شده است', 'warning')
            return redirect(url_for('admin_advanced_panel'))
        
        # تایید سیگنال
        signal.admin_approved = True
        signal.status = 'APPROVED'
        signal.approved_at = datetime.utcnow()
        signal.approved_by = 'admin'
        
        # ارسال به کانال تلگرام
        try:
            from services.telegram_service import TelegramService
            telegram_service = TelegramService()
            
            # فرمت سیگنال برای ارسال
            signal_message = _format_signal_for_channel(signal)
            
            # ارسال به کانال (async در background)
            import threading
            threading.Thread(
                target=_send_signal_to_channel_async,
                args=(telegram_service, signal_message, signal.id)
            ).start()
            
        except Exception as telegram_error:
            app.logger.error(f"خطا در ارسال سیگنال به تلگرام: {telegram_error}")
            # سیگنال تایید می‌شود حتی اگر ارسال تلگرام ناموفق باشد
        
        db.session.commit()
        
        # ثبت لاگ
        _log_admin_action('SIGNAL_APPROVED', f'سیگنال {signal_id} تایید و ارسال شد')
        
        flash('سیگنال تایید و به کانال ارسال شد', 'success')
        return redirect(url_for('admin_advanced_panel'))
        
    except Exception as e:
        app.logger.error(f"خطا در تایید سیگنال {signal_id}: {e}")
        flash(f'خطا در تایید سیگنال: {str(e)}', 'error')
        return redirect(url_for('admin_advanced_panel'))


@app.route('/admin/signal/<int:signal_id>/reject', methods=['POST'])
def reject_signal(signal_id):
    """رد سیگنال توسط ادمین"""
    try:
        signal = Signal.query.get_or_404(signal_id)
        
        # بررسی وضعیت فعلی
        if signal.status != 'PENDING_APPROVAL':
            flash('این سیگنال قبلاً پردازش شده است', 'warning')
            return redirect(url_for('admin_advanced_panel'))
        
        # دلیل رد
        rejection_reason = request.form.get('rejection_reason', 'دلیل مشخص نشده')
        
        # رد سیگنال
        signal.admin_approved = False
        signal.status = 'REJECTED'
        signal.rejected_at = datetime.utcnow()
        signal.rejected_by = 'admin'
        signal.rejection_reason = rejection_reason
        
        db.session.commit()
        
        # ثبت لاگ
        _log_admin_action('SIGNAL_REJECTED', f'سیگنال {signal_id} رد شد: {rejection_reason}')
        
        flash(f'سیگنال رد شد. دلیل: {rejection_reason}', 'info')
        return redirect(url_for('admin_advanced_panel'))
        
    except Exception as e:
        app.logger.error(f"خطا در رد سیگنال {signal_id}: {e}")
        flash(f'خطا در رد سیگنال: {str(e)}', 'error')
        return redirect(url_for('admin_advanced_panel'))


def _format_signal_for_channel(signal) -> str:
    """فرمت سیگنال برای ارسال به کانال"""
    
    signal_emoji = "📈" if signal.signal_type == 'BUY' else "📉"
    
    message = f"{signal_emoji} **سیگنال طلا - {signal.signal_type}**\n\n"
    message += f"💰 **نماد:** {signal.symbol}\n"
    message += f"⏰ **زمان:** {signal.timeframe}\n\n"
    
    message += f"🎯 **ورود:** {signal.entry_price:.2f}\n"
    message += f"🛡️ **استاپ:** {signal.stop_loss:.2f}\n"
    message += f"🏆 **تارگت:** {signal.take_profit:.2f}\n\n"
    
    message += f"📊 **R/R:** {signal.risk_reward_ratio:.1f}\n"
    message += f"🔥 **اعتماد:** {signal.confidence:.0f}%\n"
    
    # اطلاعات تحلیلی
    if signal.pattern_type:
        message += f"📈 **الگو:** {signal.pattern_type}\n"
    
    if hasattr(signal, 'smc_components') and signal.smc_components:
        message += f"🧠 **SMC:** {signal.smc_components}\n"
    
    # توضیحات ادمین
    if signal.admin_notes:
        message += f"\n📝 **نکته:** {signal.admin_notes}\n"
    
    message += f"\n⚡ تایید شده توسط ادمین"
    message += f"\n🕐 {signal.approved_at.strftime('%H:%M')}"
    
    return message


def _log_admin_action(action_type: str, description: str):
    """ثبت لاگ عملکرد ادمین"""
    try:
        log = SystemLog(
            log_type=action_type,
            message=description,
            level='INFO',
            timestamp=datetime.utcnow(),
            source='ADMIN_PANEL'
        )
        db.session.add(log)
        db.session.commit()
    except Exception as e:
        app.logger.error(f"خطا در ثبت لاگ: {e}")


@app.route('/admin/price-bot/manual-update', methods=['POST'])
def manual_price_update():
    """به‌روزرسانی دستی قیمت‌ها"""
    try:
        # Run async function in sync context
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(price_bot_service.manual_price_update())
        loop.close()
        
        if result['status'] == 'success':
            return jsonify({
                'success': True,
                'message': result['message'],
                'data': {
                    'timestamp': result['data']['timestamp'].isoformat(),
                    'sent_to_channel': result['sent_to_channel']
                }
            })
        else:
            return jsonify({
                'success': False,
                'error': result['message']
            })
            
    except Exception as e:
        app.logger.error(f"Error in manual price update: {e}")
        return jsonify({
            'success': False,
            'error': f'خطا در به‌روزرسانی دستی: {str(e)}'
        })


@app.route('/admin/price-bot/stats')
def price_bot_stats():
    """آمار ربات قیمت"""
    try:
        # Run async function in sync context
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        stats = loop.run_until_complete(price_bot_service.get_bot_statistics())
        loop.close()
        
        return jsonify({
            'success': True,
            'data': stats
        })
        
    except Exception as e:
        app.logger.error(f"Error getting price bot stats: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        })


@app.route('/admin/navasan/test-api')
def test_navasan_api():
    """تست API نوسان"""
    try:
        # Clear cache for fresh data
        navasan_service.clear_cache()
        
        # Test all endpoints
        currency_prices = navasan_service.get_currency_prices()
        gold_prices = navasan_service.get_gold_prices()
        crypto_prices = navasan_service.get_crypto_prices()
        
        # Cache stats
        cache_stats = navasan_service.get_cache_stats()
        
        return jsonify({
            'success': True,
            'data': {
                'currency': currency_prices is not None,
                'gold': gold_prices is not None,
                'crypto': crypto_prices is not None,
                'cache_stats': cache_stats,
                'timestamp': datetime.now().isoformat()
            }
        })
        
    except Exception as e:
        app.logger.error(f"Error testing Navasan API: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        })


@app.route('/admin/alerts/<int:alert_id>/acknowledge', methods=['POST'])
def acknowledge_alert(alert_id):
    """تایید هشدار"""
    try:
        alert = NavasanPriceAlert.query.get_or_404(alert_id)
        alert.acknowledged = True
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'هشدار تایید شد'
        })
        
    except Exception as e:
        app.logger.error(f"Error acknowledging alert: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        })


@app.route('/admin/action/test-weekly-report', methods=['POST'])
def test_weekly_report():
    """تست گزارش هفتگی جامع"""
    try:
        from services.scheduler_service import scheduler_service
        
        # Execute weekly report manually
        scheduler_service.weekly_comprehensive_report()
        
        return jsonify({
            'success': True,
            'message': '✅ گزارش هفتگی تست شد\n📊 گزارش جامع با تحلیل چارت و اخبار ارسال شد'
        })
        
    except Exception as e:
        app.logger.error(f"Error testing weekly report: {e}")
        return jsonify({
            'success': False,
            'message': f'❌ خطا در تست گزارش هفتگی: {str(e)}'
        })

@app.route('/admin/logs')
def admin_logs():
    """صفحه مشاهده لاگ‌ها"""
    try:
        page = request.args.get('page', 1, type=int)
        level = request.args.get('level', '')
        service = request.args.get('service', '')
        
        # Build query
        query = SystemLog.query
        
        if level:
            query = query.filter(SystemLog.level == level)
        
        if service:
            query = query.filter(SystemLog.service == service)
        
        # Paginate
        logs = query.order_by(SystemLog.timestamp.desc()).paginate(
            page=page, per_page=50, error_out=False
        )
        
        # Get available levels and services for filters
        levels = db.session.query(SystemLog.level).distinct().all()
        services = db.session.query(SystemLog.service).distinct().all()
        
        return render_template('admin_logs.html',
                             logs=logs,
                             levels=[l[0] for l in levels],
                             services=[s[0] for s in services],
                             current_level=level,
                             current_service=service)
                             
    except Exception as e:
        app.logger.error(f"Error in admin logs: {e}")
        flash(f'خطا در بارگذاری لاگ‌ها: {str(e)}', 'error')
        return redirect(url_for('admin_advanced'))


@app.route('/admin/price-records')
def admin_price_records():
    """صفحه رکوردهای قیمت"""
    try:
        page = request.args.get('page', 1, type=int)
        date_filter = request.args.get('date', '')
        
        # Build query
        query = PriceRecord.query
        
        if date_filter:
            try:
                filter_date = datetime.strptime(date_filter, '%Y-%m-%d').date()
                query = query.filter(
                    PriceRecord.timestamp >= datetime.combine(filter_date, datetime.min.time()),
                    PriceRecord.timestamp < datetime.combine(filter_date + timedelta(days=1), datetime.min.time())
                )
            except ValueError:
                pass
        
        # Paginate
        records = query.order_by(PriceRecord.timestamp.desc()).paginate(
            page=page, per_page=20, error_out=False
        )
        
        return render_template('admin_price_records.html',
                             records=records,
                             current_date=date_filter)
                             
    except Exception as e:
        app.logger.error(f"Error in admin price records: {e}")
        flash(f'خطا در بارگذاری رکوردهای قیمت: {str(e)}', 'error')
        return redirect(url_for('admin_advanced'))


@app.route('/admin/scheduler/status')
def scheduler_status():
    """وضعیت زمان‌بندی"""
    try:
        if hasattr(price_bot_service, 'scheduler'):
            jobs = []
            for job in price_bot_service.scheduler.get_jobs():
                jobs.append({
                    'id': job.id,
                    'name': job.name,
                    'next_run': job.next_run_time.isoformat() if job.next_run_time else None,
                    'trigger': str(job.trigger)
                })
            
            return jsonify({
                'success': True,
                'data': {
                    'running': price_bot_service.scheduler.running,
                    'jobs': jobs
                }
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Scheduler not initialized'
            })
            
    except Exception as e:
        app.logger.error(f"Error getting scheduler status: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        })


@app.route('/admin/scheduler/start', methods=['POST'])
def start_scheduler():
    """شروع زمان‌بندی"""
    try:
        price_bot_service.start_scheduler()
        return jsonify({
            'success': True,
            'message': 'زمان‌بندی شروع شد'
        })
        
    except Exception as e:
        app.logger.error(f"Error starting scheduler: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        })


@app.route('/admin/scheduler/stop', methods=['POST'])
def stop_scheduler():
    """توقف زمان‌بندی"""
    try:
        price_bot_service.stop_scheduler()
        return jsonify({
            'success': True,
            'message': 'زمان‌بندی متوقف شد'
        })
        
    except Exception as e:
        app.logger.error(f"Error stopping scheduler: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        })

# New APIs for Navasan Price Control
@app.route('/admin/api/manual-price-update', methods=['POST'])
def admin_manual_price_update():
    """به‌روزرسانی دستی قیمت‌های نوسان"""
    try:
        # Run async function in sync context
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(price_bot_service.manual_price_update())
        loop.close()
        
        return jsonify({
            'success': result,
            'message': 'قیمت‌های نوسان با موفقیت به‌روزرسانی شد' if result else 'خطا در به‌روزرسانی'
        })
            
    except Exception as e:
        app.logger.error(f"Manual price update error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/api/send-price-to-channel', methods=['POST'])
def admin_send_price_to_channel():
    """ارسال دستی قیمت به کانال"""
    try:
        # Get latest prices
        prices = navasan_service.get_all_prices()
        
        if prices['status'] != 'success':
            return jsonify({'success': False, 'error': 'خطا در دریافت قیمت‌ها از نوسان'}), 500
        
        # Run async function in sync context
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(price_bot_service.send_navasan_update(prices))
        loop.close()
        
        return jsonify({
            'success': result,
            'message': 'قیمت با موفقیت به کانال ارسال شد' if result else 'خطا در ارسال'
        })
            
    except Exception as e:
        app.logger.error(f"Send price to channel error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/api/test-navasan', methods=['POST'])
def admin_test_navasan_api():
    """تست API نوسان"""
    try:
        test_results = {'currency': False, 'gold': False, 'crypto': False}
        
        try:
            currency_data = navasan_service.get_currency_prices()
            test_results['currency'] = currency_data is not None
        except: pass
            
        try:
            gold_data = navasan_service.get_gold_prices()
            test_results['gold'] = gold_data is not None
        except: pass
            
        try:
            crypto_data = navasan_service.get_crypto_prices()
            test_results['crypto'] = crypto_data is not None
        except: pass
        
        all_prices = navasan_service.get_all_prices()
        
        return jsonify({
            'success': True,
            'message': 'تست API نوسان انجام شد',
            'data': {
                'test_results': test_results,
                'sample_data': all_prices,
                'api_status': all_prices['status']
            }
        })
        
    except Exception as e:
        app.logger.error(f"Test Navasan API error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/admin/database/cleanup', methods=['POST'])
def database_cleanup():
    """پاکسازی پایگاه داده"""
    try:
        # Run async function in sync context
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(price_bot_service.cleanup_old_data())
        loop.close()
        
        return jsonify({
            'success': True,
            'message': 'پاکسازی پایگاه داده انجام شد'
        })
        
    except Exception as e:
        app.logger.error(f"Error in database cleanup: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        })


@app.route('/admin/export/price-records')
def export_price_records():
    """صادرات رکوردهای قیمت"""
    try:
        from flask import make_response
        import csv
        from io import StringIO
        
        # Get date range
        start_date = request.args.get('start_date', '')
        end_date = request.args.get('end_date', '')
        
        query = PriceRecord.query
        
        if start_date:
            start_dt = datetime.strptime(start_date, '%Y-%m-%d')
            query = query.filter(PriceRecord.timestamp >= start_dt)
        
        if end_date:
            end_dt = datetime.strptime(end_date, '%Y-%m-%d') + timedelta(days=1)
            query = query.filter(PriceRecord.timestamp < end_dt)
        
        records = query.order_by(PriceRecord.timestamp.desc()).all()
        
        # Create CSV
        output = StringIO()
        writer = csv.writer(output)
        
        # Headers
        writer.writerow([
            'Timestamp', 'USD_Buy', 'USD_Sell', 'EUR_Buy', 'EUR_Sell',
            'Gold_18K', 'Gold_Mesghal', 'Coin_Emami', 'Coin_Bahar', 'Coin_Gerami',
            'BTC_Price', 'ETH_Price', 'API_Status', 'Channel_Sent'
        ])
        
        # Data
        for record in records:
            writer.writerow([
                record.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                record.usd_buy, record.usd_sell,
                record.eur_buy, record.eur_sell,
                record.gold_18k, record.gold_mesghal,
                record.gold_coin_emami, record.gold_coin_bahar, record.gold_coin_gerami,
                record.btc_price, record.eth_price,
                record.api_status, record.channel_sent
            ])
        
        output.seek(0)
        
        # Create response
        response = make_response(output.getvalue())
        response.headers['Content-Type'] = 'text/csv'
        response.headers['Content-Disposition'] = f'attachment; filename=price_records_{datetime.now().strftime("%Y%m%d")}.csv'
        
        return response
        
    except Exception as e:
        app.logger.error(f"Error exporting price records: {e}")
        flash(f'خطا در صادرات داده‌ها: {str(e)}', 'error')
        return redirect(url_for('admin_price_records'))