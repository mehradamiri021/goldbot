# 🥇 Smart Gold Trading Bot - Advanced AI Analysis System
## ربات پیشرفته تحلیل و سیگنال‌دهی طلا با هوش مصنوعی

![Python](https://img.shields.io/badge/python-v3.11+-blue.svg)
![Flask](https://img.shields.io/badge/flask-v3.0+-green.svg)
![PostgreSQL](https://img.shields.io/badge/postgresql-ready-blue.svg)
![Telegram](https://img.shields.io/badge/telegram-bot-blue.svg)

## 🎯 Overview | نمای کلی

Advanced gold market analysis platform combining **Smart Money Concepts (SMC)** with **Price Action** analysis, featuring automated signal generation, multi-timeframe analysis, and Persian language support.

سیستم پیشرفته تحلیل بازار طلا با ترکیب **مفاهیم پول هوشمند** و تحلیل **Price Action**، دارای تولید خودکار سیگنال، تحلیل چند بازه زمانی و پشتیبانی کامل از زبان فارسی.

## 🚀 Core Features | ویژگی‌های اصلی

### 🎯 PRIMARY FEATURES (اولویت اول)
- **MT5 Signal System**: Real-time signal detection with admin approval workflow
- **Smart Money Concepts**: Order Blocks, Fair Value Gaps, liquidity analysis
- **Price Action Analysis**: Pin bars, engulfing patterns, confluence zones
- **Advanced AI Reports**: Daily and weekly intelligent market analysis

### 📊 SECONDARY FEATURES (اولویت دوم)  
- **Daily Price Delivery**: Automated price announcements (11:11, 14:14, 17:17 Tehran time)
- **Multi-source Integration**: Navasan API + ZaryaalGold monitoring
- **Admin Panel**: Signal editing, entry/stop/take-profit management

### 🔧 SUPPORT FEATURES (پشتیبانی)
- **Technical Analysis**: RSI-only indicator with SMC + Price Action
- **News Integration**: Forex Factory + FXStreet (limited scope)
- **Weekly Reports**: Sunday comprehensive analysis with news summary
- **PostgreSQL Integration**: Complete database management with statistics

## 🛠️ Technology Stack | پشته تکنولوژی

- **Backend**: Python 3.11+ with Flask web framework
- **Database**: PostgreSQL with SQLAlchemy ORM
- **Analysis**: Pandas, NumPy, TA-Lib for technical indicators
- **Charts**: Plotly for professional candlestick visualization
- **Scheduling**: APScheduler for automated tasks
- **Bot Integration**: python-telegram-bot for notifications
- **Frontend**: Bootstrap with RTL Persian support

## ⚡ Quick Start | راه‌اندازی سریع

### 1. One-Click Installation (Recommended)
```bash
chmod +x one_click_install.sh
./one_click_install.sh
```

### 2. Manual Installation
```bash
# Install Python dependencies
pip install -r install_requirements.txt

# Set environment variables (optional - has defaults)
export TELEGRAM_BOT_TOKEN="your_bot_token"
export TELEGRAM_CHANNEL_ID="your_channel_id"
export TELEGRAM_ADMIN_ID="your_admin_id"
export DATABASE_URL="postgresql://user:pass@host:port/db"

# Run the application
python main.py
```

### 3. Docker Deployment
```bash
# Build and run with Docker
docker build -t goldbot .
docker run -p 5000:5000 goldbot
```

## 📋 Configuration | پیکربندی

### Environment Variables
- `TELEGRAM_BOT_TOKEN`: Telegram bot token (pre-configured)
- `TELEGRAM_CHANNEL_ID`: Target channel ID (pre-configured) 
- `TELEGRAM_ADMIN_ID`: Admin user ID (pre-configured)
- `DATABASE_URL`: PostgreSQL connection string (defaults to SQLite)
- `NAVASAN_API_KEY`: Optional API key for enhanced data

### Zero-Config Deployment
This bot comes pre-configured with working Telegram credentials for immediate testing. For production use, replace with your own credentials.

## 🎛️ Admin Panel Features | پنل مدیریت

Access the admin panel at `/admin/advanced` for:
- Signal approval and editing (entry, stop-loss, take-profit)
- Real-time system monitoring
- Manual trigger for reports and analysis
- Database statistics and performance metrics
- Telegram message logs and status

## 📊 Signal Generation Workflow | فرآیند تولید سیگنال

1. **Data Collection**: MT5 CSV files + API integration
2. **Technical Analysis**: RSI + Price Action + SMC confluence
3. **Pattern Detection**: Pin bars, engulfing, 2-candle formations
4. **Admin Approval**: Review and edit signals before publishing
5. **Channel Distribution**: Automated Telegram delivery
6. **Performance Tracking**: Success rate monitoring

## 📅 Automated Schedule | زمان‌بندی خودکار

- **Daily Reports**: 08:00 Tehran time (morning analysis)
- **Price Updates**: 11:11, 14:14, 17:17 (weekdays only)
- **Weekly Reports**: Sundays 12:12 (comprehensive analysis)
- **Market Monitoring**: Every 5 minutes (signal detection)

## 🔧 Development | توسعه

### Project Structure
```
goldbot/
├── main.py              # Application entry point
├── app.py               # Flask application factory
├── models.py            # Database models
├── routes.py            # Web routes
├── routes_admin.py      # Admin panel routes
├── services/            # Core business logic
│   ├── price_action_analyzer.py
│   ├── smc_analyzer.py
│   ├── signal_fusion_service.py
│   ├── weekly_report_service.py
│   └── ...
├── templates/           # HTML templates (Persian RTL)
├── static/              # CSS, JS, assets
└── config/              # Configuration files
```

### Key Services
- `PriceActionAnalyzer`: Pattern detection (pin bars, engulfing)
- `SmartMoneyAnalyzer`: SMC analysis (order blocks, FVG)
- `SignalFusionService`: Confluence analysis combining PA + SMC + RSI
- `WeeklyReportService`: Comprehensive weekly analysis with news
- `TelegramService`: Bot integration and message delivery

## 🐛 Troubleshooting | عیب‌یابی

### Common Issues
1. **Database Connection**: Ensure PostgreSQL is running or use SQLite fallback
2. **Telegram Bot**: Verify bot token and permissions
3. **Dependencies**: Install TA-Lib system dependencies
4. **Permissions**: Ensure execute permissions on shell scripts

### Support Files
- `DEPLOYMENT_GUIDE.md`: Detailed deployment instructions
- `PRIORITY_SYSTEM.md`: Feature priority documentation
- `FINAL_STATUS.md`: Current system status

## 📄 License | مجوز

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🤝 Contributing | مشارکت

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📞 Support | پشتیبانی

For support and questions:
- Create an issue on GitHub
- Check the documentation files
- Review the admin panel logs

---

### 🎯 Priority System
1. **PRIMARY**: MT5 Signal System + SMC Analysis (mandatory admin logging)
2. **SECONDARY**: Daily price delivery system
3. **SUPPORT**: Admin management and reporting features

**Status**: ✅ Fully Operational - All core features active and tested
**Last Updated**: August 2025
