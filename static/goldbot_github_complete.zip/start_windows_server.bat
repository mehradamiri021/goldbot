@echo off
REM Gold Trading Bot - Windows Server 2019 Startup Script
REM اسکریپت راه‌اندازی ربات طلا برای ویندوز سرور 2019

echo =====================================
echo  Gold Trading Bot - Windows Server
echo  ربات تحلیل طلا - ویندوز سرور
echo =====================================

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo خطا: Python نصب نشده است
    echo Error: Python is not installed
    echo لطفا Python 3.11 را از python.org دانلود و نصب کنید
    echo Please install Python 3.11 from python.org
    pause
    exit /b 1
)

REM Check if virtual environment exists
if not exist "venv\" (
    echo ایجاد محیط مجازی...
    echo Creating virtual environment...
    python -m venv venv
)

REM Activate virtual environment
echo فعال‌سازی محیط مجازی...
echo Activating virtual environment...
call venv\Scripts\activate.bat

REM Install Windows-compatible requirements
if not exist "requirements_installed.flag" (
    echo نصب پکیج‌های سازگار با ویندوز...
    echo Installing Windows-compatible packages...
    
    REM Install packages one by one to handle TA-Lib issue
    pip install --upgrade pip
    pip install flask==2.3.3
    pip install flask-sqlalchemy==3.0.5
    pip install python-telegram-bot==20.5
    pip install pandas==2.1.1
    pip install numpy==1.25.2
    pip install ta==0.10.2
    pip install plotly==5.17.0
    pip install apscheduler==3.10.4
    pip install pytz==2023.3
    pip install requests==2.31.0
    pip install beautifulsoup4==4.12.2
    pip install trafilatura==1.6.2
    pip install psycopg2-binary==2.9.7
    pip install email-validator==2.0.0
    
    REM Create flag file
    echo Windows packages installed > requirements_installed.flag
    echo پکیج‌ها با موفقیت نصب شدند
    echo Packages installed successfully
)

REM Set environment variables for Windows - Pre-configured
REM تنظیم متغیرهای محیط ویندوز - از پیش تنظیم شده
set FLASK_APP=main.py
set FLASK_ENV=production
set HOST=0.0.0.0
set PORT=5000

REM Telegram settings - Pre-configured
REM تنظیمات تلگرام - از پیش تنظیم شده
set TELEGRAM_BOT_TOKEN=7522433521:AAF7ugwzUy7k9OPqcGqEv_45hHsG83PpP-Y
set TELEGRAM_CHANNEL_ID=-1002717718463
set TELEGRAM_ADMIN_ID=1112066452

REM Database settings
REM تنظیمات پایگاه داده
set DATABASE_URL=sqlite:///gold_bot.db

REM Security
REM امنیت
set SESSION_SECRET=gold-bot-secure-key-2025

REM Display startup information
echo.
echo =====================================
echo  اطلاعات سرور / Server Information
echo =====================================
echo محلی / Local: http://localhost:5000
echo شبکه / Network: http://0.0.0.0:5000
echo خارجی / External: http://YOUR_SERVER_IP:5000
echo.
echo صفحات در دسترس / Available Pages:
echo - Dashboard: /dashboard
echo - Charts: /charts  
echo - Signals: /signals
echo - Settings: /settings
echo.
echo برای توقف سرور Ctrl+C را فشار دهید
echo Press Ctrl+C to stop the server
echo =====================================
echo.

REM Check if main.py exists
if not exist "main.py" (
    echo خطا: فایل main.py یافت نشد
    echo Error: main.py not found
    pause
    exit /b 1
)

REM Fix any import issues first
echo حل مشکلات import...
echo Fixing import issues...
python fix_windows_import.py

REM Start the Flask application
echo راه‌اندازی سرور...
echo Starting server...
python main.py

REM If server stops, show message
echo.
echo سرور متوقف شد
echo Server stopped
pause