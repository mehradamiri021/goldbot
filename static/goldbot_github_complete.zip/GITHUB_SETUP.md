# راهنمای تنظیم و استقرار در GitHub

## 🚀 راه‌اندازی Repository در GitHub

### مرحله 1: ایجاد Repository
```bash
# در محل پروژه
git init
git add .
git commit -m "🎉 Initial commit: Complete Gold Trading Bot with Navasan Integration"

# اتصال به GitHub
git remote add origin https://github.com/[USERNAME]/gold-trading-bot.git
git branch -M main
git push -u origin main
```

### مرحله 2: تنظیم GitHub Actions
فایل `.github/workflows/deploy.yml` برای CI/CD خودکار:

```yaml
name: Deploy Gold Trading Bot

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Set up Python 3.11
      uses: actions/setup-python@v3
      with:
        python-version: '3.11'
    
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r install_requirements_no_talib.txt
        pip install pandas-ta
    
    - name: Run tests
      run: |
        python -m pytest tests/ -v
        
    - name: Check code style
      run: |
        python -m flake8 . --count --select=E9,F63,F7,F82 --show-source --statistics

  deploy:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Deploy to Server
      uses: appleboy/ssh-action@v0.1.5
      with:
        host: ${{ secrets.HOST }}
        username: ${{ secrets.USERNAME }}
        key: ${{ secrets.SSH_KEY }}
        script: |
          cd ~/goldbot
          git pull origin main
          source venv/bin/activate
          pip install -r install_requirements_no_talib.txt
          python -c "from app import db; db.create_all()"
          sudo systemctl restart goldbot
```

### مرحله 3: تنظیم Secrets در GitHub
در تنظیمات Repository، بخش Secrets:

```
HOST: IP سرور شما
USERNAME: نام کاربری SSH
SSH_KEY: کلید SSH خصوصی
TELEGRAM_BOT_TOKEN: توکن ربات تلگرام
NAVASAN_API_KEY: کلید API نوسان
```

## 📊 ساختار پروژه برای GitHub

```
gold-trading-bot/
├── .github/
│   └── workflows/
│       └── deploy.yml
├── config/
│   ├── __init__.py
│   └── mt5_config.py
├── services/
│   ├── __init__.py
│   ├── analysis_service.py
│   ├── data_service.py
│   ├── navasan_service.py
│   ├── price_bot_service.py
│   ├── scheduler_service.py
│   ├── ta_shim.py
│   ├── telegram_service.py
│   └── zaryaal_monitor.py
├── templates/
│   ├── admin_advanced.html
│   ├── admin_logs.html
│   ├── admin_price_records.html
│   ├── dashboard.html
│   ├── index.html
│   └── signals.html
├── static/
│   ├── css/
│   ├── js/
│   └── images/
├── tests/
│   ├── __init__.py
│   ├── test_api.py
│   ├── test_models.py
│   └── test_services.py
├── .env.example
├── .gitignore
├── app.py
├── main.py
├── models.py
├── models_navasan.py
├── routes.py
├── routes_admin.py
├── install_requirements.txt
├── install_requirements_no_talib.txt
├── pyproject.toml
├── README.md
├── README_FA.md
├── GITHUB_SETUP.md
├── DEPLOYMENT_GUIDE.md
└── PATCH_NOTES.md
```

## 🔧 تنظیمات Systemd برای سرور

فایل `/etc/systemd/system/goldbot.service`:

```ini
[Unit]
Description=Gold Trading Bot with Navasan Integration
After=network.target

[Service]
Type=simple
User=trader
WorkingDirectory=/home/trader/goldbot
Environment=PATH=/home/trader/goldbot/venv/bin
ExecStart=/home/trader/goldbot/venv/bin/python main.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

فعال‌سازی:
```bash
sudo systemctl daemon-reload
sudo systemctl enable goldbot
sudo systemctl start goldbot
sudo systemctl status goldbot
```

## 🌐 تنظیم Nginx (اختیاری)

فایل `/etc/nginx/sites-available/goldbot`:

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /static {
        alias /home/trader/goldbot/static;
        expires 30d;
    }
}
```

## 📋 چک‌لیست پیش از Push

### ✅ فایل‌های ضروری
- [ ] `.env.example` (بدون مقادیر واقعی)
- [ ] `.gitignore` (شامل `.env`, `__pycache__`, etc.)
- [ ] `requirements.txt` کامل
- [ ] `README.md` جامع
- [ ] `DEPLOYMENT_GUIDE.md`

### ✅ کدهای تمیز
- [ ] حذف print statements غیرضروری
- [ ] کامنت‌گذاری کدهای مهم
- [ ] فرمت کردن کد با Black
- [ ] بررسی لینت با flake8

### ✅ امنیت
- [ ] حذف hardcoded secrets
- [ ] استفاده از environment variables
- [ ] بررسی `.gitignore`

## 🔄 فرآیند Development

### شاخه‌بندی
```bash
# شاخه جدید برای فیچر
git checkout -b feature/navasan-integration

# تغییرات
git add .
git commit -m "✨ Add Navasan API integration"

# Push به GitHub
git push origin feature/navasan-integration

# Pull Request در GitHub
```

### مدیریت نسخه‌ها
```bash
# Tag کردن نسخه
git tag -a v2.0.0 -m "🚀 Release v2.0.0: Added Navasan integration"
git push origin v2.0.0
```

## 📈 مانیتورینگ GitHub

### GitHub Actions برای مانیتورینگ
```yaml
name: Health Check

on:
  schedule:
    - cron: '*/30 * * * *'  # هر 30 دقیقه

jobs:
  health-check:
    runs-on: ubuntu-latest
    steps:
    - name: Check Server Health
      run: |
        curl -f ${{ secrets.SERVER_URL }}/api/health || exit 1
    
    - name: Notify on Failure
      if: failure()
      uses: 8398a7/action-slack@v3
      with:
        status: failure
        text: "🚨 Gold Bot Server is Down!"
```

## 📚 مستندات GitHub

### README.md ساختار
```markdown
# 🤖 Gold Trading Bot

ربات پیشرفته تحلیل و سیگنال‌دهی طلا با یکپارچه‌سازی API نوسان

## ✨ ویژگی‌ها
- تحلیل Smart Money Concepts
- یکپارچه‌سازی API نوسان
- مانیتور کانال ZaryaalGold
- پنل مدیریت پیشرفته

## 🚀 نصب سریع
\`\`\`bash
git clone https://github.com/[USER]/gold-trading-bot.git
cd gold-trading-bot
chmod +x install_ubuntu.sh
./install_ubuntu.sh
\`\`\`

## 📊 آمار
![GitHub Stars](https://img.shields.io/github/stars/[USER]/gold-trading-bot)
![License](https://img.shields.io/github/license/[USER]/gold-trading-bot)
![Issues](https://img.shields.io/github/issues/[USER]/gold-trading-bot)
```

## 🎯 استراتژی Release

### نسخه‌گذاری Semantic
- `v1.0.0`: نسخه اولیه با MT5
- `v2.0.0`: اضافه کردن Navasan API
- `v2.1.0`: بهبود پنل مدیریت
- `v2.1.1`: رفع باگ‌ها

### Changelog خودکار
```yaml
name: Generate Changelog

on:
  release:
    types: [created]

jobs:
  changelog:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - name: Generate Changelog
      uses: heinrichreimer/github-changelog-generator-action@v2.3
```

این راهنما کامل تمام مراحل انتشار و مدیریت پروژه در GitHub را پوشش می‌دهد. 🚀