#!/bin/bash
# نصب ساده ربات طلا - بدون تداخل dependency
# Simple Install - No Dependency Conflicts

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}🤖 نصب ساده ربات طلا${NC}"
echo "=================================="

# Check Python
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ پایتون 3 یافت نشد${NC}"
    echo "Ubuntu/Debian: sudo apt install python3 python3-pip python3-venv"
    exit 1
fi

echo -e "${GREEN}✅ پایتون: $(python3 --version)${NC}"

# Create virtual environment
echo -e "${YELLOW}📦 ایجاد محیط مجازی...${NC}"
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip

# Install packages with no conflicts
echo -e "${YELLOW}📚 نصب پکیج‌ها (حل شده dependency conflicts)...${NC}"

# Install core packages first
pip install --no-deps Flask==3.0.0
pip install --no-deps flask-sqlalchemy==3.1.1  
pip install --no-deps Werkzeug==3.0.1
pip install --no-deps SQLAlchemy==2.0.23

# Install with dependency resolution
pip install psycopg2-binary pandas numpy plotly requests python-telegram-bot apscheduler pytz beautifulsoup4 gunicorn python-dotenv python-dateutil

# Install lxml and trafilatura separately to avoid conflicts
pip install "lxml>=4.9.4"
pip install trafilatura

# Install optional packages
pip install pandas-ta jdatetime email-validator || echo "Optional packages failed - continuing..."

# Try TA-Lib
if pip install TA-Lib; then
    echo -e "${GREEN}✅ TA-Lib نصب شد${NC}"
else
    echo -e "${YELLOW}⚠️ TA-Lib نصب نشد - از pandas-ta استفاده می‌شود${NC}"
fi

# Create .env if not exists
if [ ! -f ".env" ]; then
    echo -e "${YELLOW}📝 ایجاد فایل .env...${NC}"
    cat > .env << 'EOF'
# ربات طلا - تنظیمات خودکار
DATABASE_URL=sqlite:///goldbot.db
FLASK_SECRET_KEY=goldbot-secret-key
SERVER_PORT=5000
TZ=Asia/Tehran

# Telegram (از قبل تنظیم شده)
TELEGRAM_BOT_TOKEN=7522433521:AAF7ugwzUy7k9OPqcGqEv_45hHsG83PpP-Y
TELEGRAM_CHANNEL_ID=-1002717718463
TELEGRAM_ADMIN_ID=1112066452

# API نواسان (رایگان)
NAVASAN_API_KEY=freeL3ceMoBm2EaeVeuvHJvuGKTJcNcg
EOF
fi

# Create start script
cat > start.sh << 'EOF'
#!/bin/bash
echo "🚀 شروع ربات طلا..."
if [ -f .env ]; then
    export $(cat .env | grep -v '^#' | xargs)
fi
source venv/bin/activate
exec gunicorn --bind 0.0.0.0:${SERVER_PORT:-5000} --workers 2 --reload main:app
EOF
chmod +x start.sh

# Create stop script  
cat > stop.sh << 'EOF'
#!/bin/bash
echo "⏹️ توقف ربات..."
pkill -f "gunicorn.*main:app" || echo "فرآیند یافت نشد"
EOF
chmod +x stop.sh

# Test system
echo -e "${YELLOW}🧪 تست سیستم...${NC}"
if python3 -c "from main import initialize_app; initialize_app()" 2>/dev/null; then
    echo -e "${GREEN}✅ سیستم آماده است${NC}"
else
    echo -e "${YELLOW}⚠️ ممکن است نیاز به تنظیمات اضافی باشد${NC}"
fi

echo
echo -e "${GREEN}🎉 نصب کامل شد!${NC}"
echo -e "${BLUE}🚀 شروع: ./start.sh${NC}"  
echo -e "${BLUE}🌐 دسترسی: http://localhost:5000${NC}"
echo -e "${BLUE}⏹️ توقف: ./stop.sh${NC}"