#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Fix TA-Lib Installation Issues on Windows
حل مشکل نصب TA-Lib در ویندوز
"""

import os
import sys
import shutil
from pathlib import Path

def fix_analysis_service():
    """Replace TA-Lib with ta library in analysis service"""
    print("🔧 اصلاح سرویس تحلیل برای ویندوز...")
    print("🔧 Fixing analysis service for Windows...")
    
    # Copy Windows-compatible analysis service
    if os.path.exists('services/analysis_service_windows.py'):
        if os.path.exists('services/analysis_service.py'):
            # Backup original
            shutil.copy2('services/analysis_service.py', 'services/analysis_service.py.backup')
            print("📋 فایل اصلی پشتیبان‌گیری شد")
            print("📋 Original file backed up")
        
        # Replace with Windows version
        shutil.copy2('services/analysis_service_windows.py', 'services/analysis_service.py')
        print("✅ سرویس تحلیل ویندوز جایگزین شد")
        print("✅ Windows analysis service replaced")
        return True
    else:
        print("❌ فایل سرویس ویندوز یافت نشد")
        print("❌ Windows service file not found")
        return False

def check_requirements():
    """Check if Windows requirements file exists"""
    if os.path.exists('install_requirements_windows.txt'):
        print("✅ فایل پکیج‌های ویندوز موجود است")
        print("✅ Windows requirements file exists")
        return True
    else:
        print("❌ فایل پکیج‌های ویندوز موجود نیست")
        print("❌ Windows requirements file missing")
        return False

def create_install_script():
    """Create Windows installation script"""
    install_script = '''@echo off
REM Gold Trading Bot - Windows Installation Script
REM اسکریپت نصب ربات طلا - ویندوز

echo.
echo ===================================
echo    Gold Trading Bot Installation
echo    نصب ربات تحلیل و سیگنال طلا
echo ===================================
echo.

echo Step 1: Installing Python packages for Windows...
echo مرحله 1: نصب پکیج‌های پایتون برای ویندوز...

REM Use Windows-compatible requirements
if exist install_requirements_windows.txt (
    echo Using Windows-compatible packages...
    echo استفاده از پکیج‌های سازگار ویندوز...
    pip install -r install_requirements_windows.txt
) else (
    echo Windows requirements file not found, using standard requirements...
    echo فایل پکیج‌های ویندوز یافت نشد، استفاده از پکیج‌های استاندارد...
    pip install -r install_requirements.txt
)

echo.
echo Step 2: Fixing analysis service for Windows...
echo مرحله 2: اصلاح سرویس تحلیل برای ویندوز...

python fix_ta_lib_windows.py

echo.
echo Step 3: Creating environment file...
echo مرحله 3: ایجاد فایل محیط...

if not exist .env (
    copy .env.example .env
    echo Environment file created from template
    echo فایل محیط از قالب ایجاد شد
)

echo.
echo ===================================
echo Installation completed!
echo نصب تکمیل شد!
echo.
echo To start the bot, run: python main.py
echo برای راه‌اندازی ربات اجرا کنید: python main.py
echo ===================================
echo.
pause
'''
    
    with open('install_windows_fixed.bat', 'w', encoding='utf-8') as f:
        f.write(install_script)
    
    print("✅ اسکریپت نصب ویندوز ایجاد شد")
    print("✅ Windows install script created")

def main():
    """Main function"""
    print("🚀 شروع اصلاح مشکلات TA-Lib در ویندوز...")
    print("🚀 Starting TA-Lib fixes for Windows...")
    print()
    
    # Check current directory
    current_dir = Path.cwd()
    print(f"📁 پوشه جاری: {current_dir}")
    print(f"📁 Current directory: {current_dir}")
    print()
    
    # Fix analysis service
    if fix_analysis_service():
        print("✅ سرویس تحلیل اصلاح شد")
        print("✅ Analysis service fixed")
    
    # Check requirements
    if check_requirements():
        print("✅ فایل پکیج‌های ویندوز موجود است")
        print("✅ Windows requirements file available")
    
    # Create installation script
    create_install_script()
    
    print()
    print("="*50)
    print("🎉 اصلاحات تکمیل شد!")
    print("🎉 Fixes completed!")
    print()
    print("📋 مراحل بعدی:")
    print("📋 Next steps:")
    print("1. اجرا کنید: install_windows_fixed.bat")
    print("1. Run: install_windows_fixed.bat")
    print("2. یا دستی: pip install -r install_requirements_windows.txt")
    print("2. Or manually: pip install -r install_requirements_windows.txt")
    print("3. سپس: python main.py")
    print("3. Then: python main.py")
    print("="*50)

if __name__ == "__main__":
    main()