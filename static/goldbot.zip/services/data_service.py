import requests
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

class GoldDataService:
    def __init__(self):
        # Primary data source: MetaTrader 5
        self.use_mt5 = True
        self.mt5_service = None
        
        # Fallback API URL
        self.api_url = "http://46.100.50.194:5050/get_data"
        self.cache = {}
        self.cache_expiry = {}
        
        # Initialize MT5 service
        self._initialize_mt5()
    
    def _initialize_mt5(self):
        """Initialize MetaTrader 5 service"""
        try:
            from services.mt5_data_service import mt5_service
            self.mt5_service = mt5_service
            if self.mt5_service.test_connection():
                logger.info("✅ MT5 data service initialized successfully")
                self.use_mt5 = True
            else:
                logger.warning("⚠️ MT5 not available, using API fallback")
                self.use_mt5 = False
        except ImportError:
            logger.warning("⚠️ MT5 module not available, using API fallback")
            self.use_mt5 = False
        except Exception as e:
            logger.error(f"❌ Error initializing MT5 service: {e}")
            self.use_mt5 = False
    
    def get_gold_data(self, timeframe='H1', limit=1000):
        """Get gold price data from MetaTrader 5 or API fallback"""
        
        # Try MetaTrader 5 first
        if self.use_mt5 and self.mt5_service:
            try:
                logger.info(f"📊 Getting {timeframe} data from MetaTrader 5...")
                df = self.mt5_service.get_gold_data(timeframe, limit)
                if df is not None and len(df) > 0:
                    logger.info(f"✅ Successfully got {len(df)} candles from MT5")
                    return df
                else:
                    logger.warning("⚠️ MT5 returned empty data, trying API fallback")
            except Exception as e:
                logger.error(f"❌ MT5 data fetch failed: {e}")
                logger.warning("⚠️ Falling back to external API")
        
        # Fallback to external API
        return self._get_api_data(timeframe, limit)
    
    def _get_api_data(self, timeframe='H1', limit=1000):
        """Get gold price data from external API"""
        try:
            cache_key = f"api_{timeframe}_{limit}"
            current_time = datetime.now()
            
            # Check cache
            if cache_key in self.cache:
                if current_time < self.cache_expiry[cache_key]:
                    logger.info(f"Using cached API data for {cache_key}")
                    return self.cache[cache_key]
            
            params = {
                'symbol': 'XAUUSD',
                'timeframe': timeframe,
                'limit': limit
            }
            
            logger.info(f"📡 Fetching data from external API: {self.api_url}")
            response = requests.get(self.api_url, params=params, timeout=30)
            response.raise_for_status()
            
            data = response.json()
            
            # Convert to DataFrame
            df = pd.DataFrame(data)
            
            # Ensure proper column names and types
            expected_columns = ['timestamp', 'open', 'high', 'low', 'close', 'volume']
            for col in expected_columns:
                if col not in df.columns:
                    logger.warning(f"Missing column: {col}")
                    if col == 'volume':
                        df[col] = 0
                    else:
                        raise ValueError(f"Required column {col} missing from API response")
            
            # Convert timestamp to datetime
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            
            # Convert price columns to float
            price_columns = ['open', 'high', 'low', 'close']
            for col in price_columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
            
            # Sort by timestamp
            df = df.sort_values('timestamp')
            
            # Cache the data
            cache_duration = {
                'M15': 5,
                'H1': 15,
                'H4': 60,
                'D1': 240
            }.get(timeframe, 15)
            
            self.cache[cache_key] = df
            self.cache_expiry[cache_key] = current_time + timedelta(minutes=cache_duration)
            
            logger.info(f"✅ Successfully fetched {len(df)} candles from API for {timeframe}")
            return df
            
        except requests.exceptions.RequestException as e:
            logger.error(f"❌ API request error: {e}")
            # Generate fallback demo data
            return self._generate_fallback_data(timeframe, limit)
            
        except Exception as e:
            logger.error(f"❌ Error processing API response: {e}")
            # Generate fallback demo data
            return self._generate_fallback_data(timeframe, limit)
    
    def get_current_price(self):
        """Get current gold price"""
        if self.use_mt5 and self.mt5_service:
            try:
                current_price = self.mt5_service.get_current_price()
                if current_price:
                    return current_price
            except Exception as e:
                logger.error(f"❌ Error getting current price from MT5: {e}")
        
        # Fallback: get from recent data
        try:
            df = self.get_gold_data('M1', 1)
            if df is not None and len(df) > 0:
                latest = df.iloc[-1]
                return {
                    'bid': latest['close'],
                    'ask': latest['close'] + 0.5,  # Estimated spread
                    'time': latest['timestamp'],
                    'spread': 0.5
                }
        except Exception as e:
            logger.error(f"❌ Error getting current price: {e}")
        
        return None
    
    def get_market_info(self):
        """Get market information"""
        if self.use_mt5 and self.mt5_service:
            try:
                market_info = self.mt5_service.get_market_info()
                if market_info:
                    return market_info
            except Exception as e:
                logger.error(f"❌ Error getting market info from MT5: {e}")
        
        # Fallback market info
        return {
            'symbol': 'XAUUSD',
            'spread': 0.5,
            'digits': 2,
            'point': 0.01,
            'min_lot': 0.01,
            'max_lot': 100.0,
            'lot_step': 0.01
        }
    
    def _generate_fallback_data(self, timeframe='H1', limit=1000):
        """Generate realistic fallback gold price data when API is unavailable"""
        try:
            logger.warning(f"Using fallback demo data for {timeframe} - {limit+1} candles generated")
            
            # Base gold price around current market levels
            base_price = 2650.0
            
            # Generate timestamps
            from datetime import datetime, timedelta
            
            # Time intervals based on timeframe
            intervals = {
                'M15': 15,  # 15 minutes
                'H1': 60,   # 1 hour
                'H4': 240,  # 4 hours
                'D1': 1440  # 1 day
            }
            
            interval_minutes = intervals.get(timeframe, 60)
            end_time = datetime.now()
            
            data = []
            current_price = base_price
            
            for i in range(limit):
                # Generate realistic price movements
                volatility = np.random.normal(0, 2.5)  # Gold volatility
                price_change = volatility
                
                # Add some trend and mean reversion
                if i % 50 == 0:  # Trend changes
                    trend = np.random.uniform(-0.5, 0.5)
                else:
                    trend = 0
                
                # Calculate OHLC
                open_price = current_price
                
                # Random high/low within reasonable range
                high_offset = abs(np.random.normal(0, 1.5))
                low_offset = abs(np.random.normal(0, 1.5))
                
                high_price = open_price + high_offset
                low_price = open_price - low_offset
                
                close_price = open_price + price_change + trend
                
                # Ensure high is highest and low is lowest
                high_price = max(high_price, open_price, close_price)
                low_price = min(low_price, open_price, close_price)
                
                # Calculate timestamp
                timestamp = end_time - timedelta(minutes=interval_minutes * (limit - i - 1))
                
                data.append({
                    'timestamp': timestamp,
                    'open': round(open_price, 2),
                    'high': round(high_price, 2),
                    'low': round(low_price, 2),
                    'close': round(close_price, 2),
                    'volume': np.random.randint(1000, 5000)
                })
                
                current_price = close_price
                
                # Add some mean reversion
                if abs(current_price - base_price) > 50:
                    current_price += (base_price - current_price) * 0.1
            
            df = pd.DataFrame(data)
            df = df.sort_values('timestamp')
            
            return df
            
        except Exception as e:
            logger.error(f"Error generating fallback data: {e}")
            # Return minimal fallback
            from datetime import datetime
            return pd.DataFrame({
                'timestamp': [datetime.now()],
                'open': [2650.0],
                'high': [2655.0],
                'low': [2645.0],
                'close': [2652.0],
                'volume': [1000]
            })
    
    def test_connections(self):
        """Test all data source connections"""
        results = {
            'mt5': False,
            'api': False,
            'status': 'No data sources available'
        }
        
        # Test MT5 connection
        if self.use_mt5 and self.mt5_service:
            try:
                results['mt5'] = self.mt5_service.test_connection()
                if results['mt5']:
                    results['status'] = 'MT5 connected'
                    logger.info("✅ MT5 connection test passed")
            except Exception as e:
                logger.error(f"❌ MT5 connection test failed: {e}")
        
        # Test API connection
        try:
            params = {
                'symbol': 'XAUUSD',
                'timeframe': 'H1',
                'limit': 10
            }
            
            response = requests.get(self.api_url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            results['api'] = True
            logger.info(f"✅ API connection successful - received {len(data)} records")
            
            if not results['mt5']:
                results['status'] = 'API connected (MT5 unavailable)'
            else:
                results['status'] = 'Both MT5 and API connected'
                
        except Exception as e:
            logger.error(f"❌ API connection failed: {e}")
            if not results['mt5']:
                results['status'] = 'All data sources failed - using fallback data'
        
        return results


# Global instance for use across the application
data_service = GoldDataService()

def get_gold_data(timeframe='H1', limit=1000):
    """Convenience function to get gold data"""
    return data_service.get_gold_data(timeframe, limit)

def get_multiple_timeframes():
    """Convenience function to get multiple timeframes"""
    timeframes = ['M15', 'H1', 'H4', 'D1']
    data = {}
    
    for tf in timeframes:
        try:
            limit = {'M15': 200, 'H1': 200, 'H4': 100, 'D1': 50}[tf]
            data[tf] = data_service.get_gold_data(tf, limit)
            logger.info(f"Fetched {len(data[tf])} candles for {tf}")
        except Exception as e:
            logger.error(f"Error fetching {tf} data: {e}")
            data[tf] = None
    
    return data

def get_current_price():
    """Convenience function to get current price"""
    current_price = data_service.get_current_price()
    if current_price and isinstance(current_price, dict):
        return current_price.get('bid', current_price.get('close', 2650.0))
    return 2650.0  # Default fallback price
